// server.js – Main Express application
require('dotenv').config();

const express      = require('express');
const path         = require('path');
const helmet       = require('helmet');
const session      = require('express-session');
const pgSession    = require('connect-pg-simple')(session);
const rateLimit    = require('express-rate-limit');
const pool         = require('./db/db');

// ── Route modules ─────────────────────────────────────────────────────────────
const authRouter     = require('./routes/auth');
const eventsRouter   = require('./routes/events');
const shareRouter    = require('./routes/share');
const scheduleRouter = require('./routes/schedule');
const adminRouter    = require('./routes/admin');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Security headers ──────────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'", "'unsafe-inline'"],
      styleSrc:   ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc:    ["'self'", 'data:', 'https://fonts.gstatic.com'],
      imgSrc:     ["'self'", 'data:'],
      connectSrc: ["'self'"],
    }
  }
}));

// ── Body parsing ──────────────────────────────────────────────────────────────
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Session ───────────────────────────────────────────────────────────────────
app.use(session({
  store: new pgSession({
    pool,
    tableName: 'session',
    createTableIfMissing: true,
  }),
  secret:            process.env.SESSION_SECRET || 'dev-secret-change-me',
  resave:            false,
  saveUninitialized: false,
  cookie: {
    secure:   process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'lax',
    maxAge:   24 * 60 * 60 * 1000, // 24 hours
  }
}));

// ── Global rate limit ─────────────────────────────────────────────────────────
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders:   false,
}));

// ── API routes ────────────────────────────────────────────────────────────────
app.use('/auth',     authRouter);
app.use('/events',   eventsRouter);
app.use('/share',    shareRouter);
app.use('/schedule', scheduleRouter);
app.use('/admin',    adminRouter);

// ── Page routes ───────────────────────────────────────────────────────────────
app.get('/shared/:token', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'shared.html')));

app.get('/live', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'live.html')));

app.get('/login', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'login.html')));

app.get('/admin-dashboard', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'admin.html')));

// ── Static files ──────────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ── 404 handler ───────────────────────────────────────────────────────────────
const API_PREFIXES = ['/auth', '/events', '/share', '/schedule', '/admin'];
app.use((req, res) => {
  const isApiCall = req.xhr
    || req.headers.accept?.includes('application/json')
    || API_PREFIXES.some(p => req.path.startsWith(p));
  if (isApiCall) return res.status(404).json({ error: 'Not found' });
  res.status(404).sendFile(path.join(__dirname, 'public', 'login.html'));
});

// ── Error handler ─────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`⛳ Golf Scheduler running on http://localhost:${PORT}`);
  console.log(`   NODE_ENV: ${process.env.NODE_ENV || 'development'}`);
});
