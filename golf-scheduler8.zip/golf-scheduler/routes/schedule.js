// routes/schedule.js
const express = require('express');
const { param, query, body, validationResult } = require('express-validator');
const { requireAuth } = require('../middleware/auth');
const pool = require('../db/db');

const router = express.Router();

// ── Shared helper: find week number for a given date in a config ──────────────
function findWeekForDate(config, date) {
  if (!config || !config.weekDates) return null;
  const target = date; // 'YYYY-MM-DD'
  for (const [week, wDate] of Object.entries(config.weekDates)) {
    if (wDate === target) return week;
  }
  return null;
}

// ── Build week summary from saved schedule + config ───────────────────────────
function buildWeekSummary(config, savedSchedule, week) {
  const weekKey = String(week);
  const aggW  = new Set(config.aggregateWeeks  || []);
  const trnW  = new Set(config.tournamentWeeks || []);
  const scrW  = new Set(config.scrambleWeeks   || []);
  const bbW   = new Set(config.bestballWeeks   || []);

  const types = [];
  if (trnW.has(weekKey)) types.push('TOURNAMENT');
  if (aggW.has(weekKey)) types.push('AGGREGATE');
  if (scrW.has(weekKey)) types.push('SCRAMBLE');
  if (bbW.has(weekKey))  types.push('2-MAN BEST BALL');
  if (types.length === 0) types.push('REGULAR');

  const playerStatus = savedSchedule?.[weekKey]?.playerStatus || null;
  const available    = config.availability?.[weekKey] || [];

  return {
    week:        weekKey,
    date:        config.weekDates?.[weekKey]  || null,
    name:        config.weekNames?.[weekKey]  || null,
    types,
    players:     config.players || [],
    available,   // raw availability list even if no generated schedule
    playerStatus // null when no schedule has been generated + saved yet
  };
}

// ── GET /schedule/live/:id?date=YYYY-MM-DD ────────────────────────────────────
// Owner-only live view for a specific event + date
router.get('/live/:id', requireAuth, [
  param('id').isInt(),
  query('date').optional().isISO8601(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const result = await pool.query(
      `SELECT id, title, event_date, location, config FROM events
       WHERE id = $1 AND creator_id = $2`,
      [req.params.id, req.session.userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Event not found.' });

    const event  = result.rows[0];
    const config = event.config || {};
    const date   = req.query.date || null;

    // All weeks with metadata (for the date-picker timeline)
    const allWeeks = [];
    const weekCount = config.weekCount || 0;
    for (let i = 1; i <= weekCount; i++) {
      const k = String(i);
      allWeeks.push({
        week: k,
        date: config.weekDates?.[k] || null,
        name: config.weekNames?.[k] || null,
      });
    }

    let weekSummary = null;
    if (date) {
      const matchedWeek = findWeekForDate(config, date);
      if (matchedWeek) {
        weekSummary = buildWeekSummary(config, config.generatedSchedule, matchedWeek);
      }
    }

    res.json({
      id:    event.id,
      title: event.title,
      location: event.location,
      allWeeks,
      weekSummary,
      hasGeneratedSchedule: !!config.generatedSchedule,
    });
  } catch (err) {
    console.error('schedule/live:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /schedule/live/shared/:token?date=YYYY-MM-DD ─────────────────────────
// Public live view via share token (no auth required)
router.get('/live/shared/:token', [
  query('date').optional().isISO8601(),
], async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT e.id, e.title, e.location, e.config, u.username AS creator
       FROM events e JOIN users u ON u.id = e.creator_id
       WHERE e.share_token = $1 AND e.share_active = TRUE`,
      [req.params.token]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Share link not found or has been disabled.' });
    }

    const event  = result.rows[0];
    const config = event.config || {};
    const date   = req.query.date || null;

    const weekCount = config.weekCount || 0;
    const allWeeks  = [];
    for (let i = 1; i <= weekCount; i++) {
      const k = String(i);
      allWeeks.push({
        week: k,
        date: config.weekDates?.[k] || null,
        name: config.weekNames?.[k] || null,
      });
    }

    let weekSummary = null;
    if (date) {
      const matchedWeek = findWeekForDate(config, date);
      if (matchedWeek) {
        weekSummary = buildWeekSummary(config, config.generatedSchedule, matchedWeek);
      }
    }

    res.json({
      id:      event.id,
      title:   event.title,
      creator: event.creator,
      location: event.location,
      allWeeks,
      weekSummary,
      hasGeneratedSchedule: !!config.generatedSchedule,
    });
  } catch (err) {
    console.error('schedule/live/shared:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
