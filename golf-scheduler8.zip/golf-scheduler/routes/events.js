// routes/events.js
const express = require('express');
const { body, param, validationResult } = require('express-validator');
const { requireAuth } = require('../middleware/auth');
const pool = require('../db/db');

const router = express.Router();
router.use(requireAuth);

// ── GET /events ───────────────────────────────────────────────────────────────
// List events created by the current user only
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT e.id, e.title, e.description, e.event_date, e.location,
              e.share_active, e.created_at,
              u.username AS creator,
              (SELECT COUNT(*) FROM rsvps r WHERE r.event_id = e.id AND r.status='attending') AS rsvp_count
       FROM events e
       JOIN users u ON u.id = e.creator_id
       WHERE e.creator_id = $1
       ORDER BY e.event_date ASC NULLS LAST, e.created_at DESC`,
      [req.session.userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error('events/list:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /events/:id ───────────────────────────────────────────────────────────
// Owner-only: no public access through this route (public access is via /share/view/:token)
router.get('/:id', [param('id').isInt()], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const result = await pool.query(
      `SELECT e.*, u.username AS creator
       FROM events e JOIN users u ON u.id = e.creator_id
       WHERE e.id = $1 AND e.creator_id = $2`,
      [req.params.id, req.session.userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Event not found.' });

    const rsvps = await pool.query(
      `SELECT r.status, u.username
       FROM rsvps r JOIN users u ON u.id = r.user_id
       WHERE r.event_id = $1`,
      [req.params.id]
    );

    res.json({ ...result.rows[0], rsvps: rsvps.rows });
  } catch (err) {
    console.error('events/get:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /events ──────────────────────────────────────────────────────────────
router.post('/', [
  body('title').trim().isLength({ min: 1, max: 255 }).escape(),
  body('description').optional().trim(),
  body('event_date').optional().isISO8601(),
  body('location').optional().trim().isLength({ max: 255 }).escape(),
  body('config').optional().isObject(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { title, description, event_date, location, config } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO events (title, description, event_date, location, config, creator_id)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [title, description || null, event_date || null, location || null,
       config ? JSON.stringify(config) : '{}', req.session.userId]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('events/create:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── PUT /events/:id ───────────────────────────────────────────────────────────
router.put('/:id', [
  param('id').isInt(),
  body('title').optional().trim().isLength({ min: 1, max: 255 }).escape(),
  body('description').optional().trim(),
  body('event_date').optional().isISO8601(),
  body('location').optional().trim().isLength({ max: 255 }).escape(),
  body('config').optional().isObject(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { title, description, event_date, location, config } = req.body;
  try {
    const own = await pool.query(
      'SELECT id FROM events WHERE id=$1 AND creator_id=$2',
      [req.params.id, req.session.userId]
    );
    if (own.rows.length === 0) return res.status(403).json({ error: 'Forbidden.' });

    const fields = [];
    const vals   = [];
    let idx = 1;

    if (title       !== undefined) { fields.push(`title=$${idx++}`);       vals.push(title); }
    if (description !== undefined) { fields.push(`description=$${idx++}`); vals.push(description); }
    if (event_date  !== undefined) { fields.push(`event_date=$${idx++}`);  vals.push(event_date); }
    if (location    !== undefined) { fields.push(`location=$${idx++}`);    vals.push(location); }
    if (config      !== undefined) { fields.push(`config=$${idx++}`);      vals.push(JSON.stringify(config)); }

    if (fields.length === 0) return res.status(400).json({ error: 'Nothing to update.' });

    fields.push(`updated_at=NOW()`);
    vals.push(req.params.id);

    const result = await pool.query(
      `UPDATE events SET ${fields.join(', ')} WHERE id=$${idx} RETURNING *`,
      vals
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error('events/update:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── DELETE /events/:id ────────────────────────────────────────────────────────
router.delete('/:id', [param('id').isInt()], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const result = await pool.query(
      'DELETE FROM events WHERE id=$1 AND creator_id=$2 RETURNING id',
      [req.params.id, req.session.userId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Event not found or not yours.' });
    }
    res.json({ message: 'Event deleted.' });
  } catch (err) {
    console.error('events/delete:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /events/:id/rsvp ─────────────────────────────────────────────────────
router.post('/:id/rsvp', [
  param('id').isInt(),
  body('status').isIn(['attending', 'maybe', 'declined']),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { status } = req.body;
  try {
    // Allow RSVP only if the user owns the event (others would need a share token flow)
    const check = await pool.query(
      'SELECT id FROM events WHERE id=$1 AND creator_id=$2',
      [req.params.id, req.session.userId]
    );
    if (check.rows.length === 0) return res.status(403).json({ error: 'Forbidden.' });

    await pool.query(
      `INSERT INTO rsvps (user_id, event_id, status) VALUES ($1, $2, $3)
       ON CONFLICT (user_id, event_id) DO UPDATE SET status = EXCLUDED.status`,
      [req.session.userId, req.params.id, status]
    );
    res.json({ message: 'RSVP saved.', status });
  } catch (err) {
    console.error('events/rsvp:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── PATCH /events/:id/availability/fill ──────────────────────────────────────
// Bulk-set all players in a week to available or unavailable and persist to DB
router.patch('/:id/availability/fill', [
  param('id').isInt(),
  body('week').trim().notEmpty(),
  body('available').isBoolean(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { week, available } = req.body;
  try {
    // Fetch event + verify ownership
    const result = await pool.query(
      'SELECT config FROM events WHERE id=$1 AND creator_id=$2',
      [req.params.id, req.session.userId]
    );
    if (result.rows.length === 0) return res.status(403).json({ error: 'Forbidden.' });

    const config = result.rows[0].config || {};
    const players = config.players || [];

    // Update availability for the week
    if (!config.availability) config.availability = {};
    config.availability[String(week)] = available ? [...players] : [];

    await pool.query(
      'UPDATE events SET config=$1, updated_at=NOW() WHERE id=$2',
      [JSON.stringify(config), req.params.id]
    );

    res.json({
      message:      `Week ${week} availability set to ${available ? 'ALL' : 'NONE'}.`,
      week:         String(week),
      available,
      updatedList:  config.availability[String(week)],
    });
  } catch (err) {
    console.error('events/availability/fill:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
