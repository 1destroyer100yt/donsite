// middleware/auth.js

/** Require a logged-in session; redirect to login if not. */
function requireAuth(req, res, next) {
  if (req.session && req.session.userId) return next();
  if (req.xhr || req.headers['content-type']?.includes('application/json')) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  res.redirect('/login');
}

/** Require admin role. */
function requireAdmin(req, res, next) {
  if (req.session && req.session.role === 'admin') return next();
  if (req.xhr || req.headers['content-type']?.includes('application/json')) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  res.status(403).send('<h1>403 Forbidden</h1><p>Admins only.</p>');
}

module.exports = { requireAuth, requireAdmin };
