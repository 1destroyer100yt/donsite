-- Golf Scheduler Database Schema
-- Run: psql -U postgres -d golf_scheduler -f db/schema.sql

CREATE TABLE IF NOT EXISTS users (
  id          SERIAL PRIMARY KEY,
  username    VARCHAR(50)  NOT NULL UNIQUE,
  email       VARCHAR(255) NOT NULL UNIQUE,
  password    VARCHAR(255) NOT NULL,
  role        VARCHAR(20)  NOT NULL DEFAULT 'user',   -- 'admin' | 'user'
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS events (
  id           SERIAL PRIMARY KEY,
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  event_date   DATE,
  location     VARCHAR(255),
  config       JSONB        NOT NULL DEFAULT '{}',  -- stores full scheduler state
  share_token  VARCHAR(64)  UNIQUE,
  share_active BOOLEAN      NOT NULL DEFAULT FALSE,
  creator_id   INTEGER      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rsvps (
  id         SERIAL PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_id   INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  status     VARCHAR(20) NOT NULL DEFAULT 'attending',  -- 'attending' | 'maybe' | 'declined'
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, event_id)
);

CREATE TABLE IF NOT EXISTS session (
  sid    VARCHAR      NOT NULL COLLATE "default",
  sess   JSON         NOT NULL,
  expire TIMESTAMP(6) NOT NULL,
  CONSTRAINT session_pkey PRIMARY KEY (sid)
);

CREATE INDEX IF NOT EXISTS idx_events_creator  ON events(creator_id);
CREATE INDEX IF NOT EXISTS idx_rsvps_user      ON rsvps(user_id);
CREATE INDEX IF NOT EXISTS idx_rsvps_event     ON rsvps(event_id);
CREATE INDEX IF NOT EXISTS idx_session_expire  ON session(expire);
