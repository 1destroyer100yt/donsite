# ⛳ Golf Group Scheduler — Full-Stack App

Node.js + Express web application for golf group scheduling with authentication,
persistent event storage, public share links, and admin controls.

---

## Architecture

```
golf-scheduler/
├── server.js                  # Express entry point
├── package.json
├── .env.example               # Copy to .env and configure
├── db/
│   ├── schema.sql             # PostgreSQL table definitions
│   ├── migrate.js             # Run once: creates all tables
│   └── db.js                  # Shared pg pool
├── routes/
│   ├── auth.js                # /auth — register, login, logout, change-password
│   ├── events.js              # /events — CRUD + RSVP
│   ├── share.js               # /share — public link generation
│   └── admin.js               # /admin — user & event management (admin only)
├── middleware/
│   └── auth.js                # requireAuth, requireAdmin
└── public/
    ├── index.html             # Main scheduler SPA (requires login)
    ├── login.html             # Login + register
    ├── admin.html             # Admin dashboard
    └── shared.html            # Public read-only shared schedule view
```

---

## Quick Start (Debian 12)

### 1. Install Node.js 20 + PostgreSQL

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs postgresql postgresql-contrib
```

### 2. Create the database and user

```bash
sudo -u postgres psql <<SQL
CREATE USER golf_user WITH PASSWORD 'strong_password_here';
CREATE DATABASE golf_scheduler OWNER golf_user;
\q
SQL
```

### 3. Configure environment

```bash
cp .env.example .env
nano .env
```

Fill in at minimum:
```
DB_PASSWORD=strong_password_here
SESSION_SECRET=<run: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))">
APP_URL=http://your-server-ip-or-domain
```

### 4. Install packages + run migration

```bash
npm install
node db/migrate.js
```

### 5. Start

```bash
# Development (auto-reload)
npm run dev

# Production
npm start

# Production with PM2
sudo npm install -g pm2
pm2 start server.js --name golf-scheduler
pm2 save && pm2 startup
```

---

## First Admin User

Register any account normally, then promote via psql:

```bash
sudo -u postgres psql golf_scheduler
UPDATE users SET role='admin' WHERE username='your_username';
\q
```

Admin dashboard is at `/admin-dashboard`.

---

## Nginx Reverse Proxy

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    location / {
        proxy_pass         http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
    }
}
```

```bash
sudo apt install -y nginx certbot python3-certbot-nginx
sudo nano /etc/nginx/sites-available/golf-scheduler
sudo ln -s /etc/nginx/sites-available/golf-scheduler /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d yourdomain.com
```

---

## API Reference

### Auth  `/auth`
| Method | Path | Description |
|--------|------|-------------|
| POST | `/auth/register` | `{username, email, password}` — auto-logs in |
| POST | `/auth/login` | `{login, password}` — login = username or email |
| POST | `/auth/logout` | Destroys session |
| GET  | `/auth/me` | Returns current session user |
| POST | `/auth/change-password` | `{currentPassword, newPassword}` — logged-in users |

> **Note:** No email/forgot-password flow. If a user is locked out, an admin
> can set a new bcrypt hash directly via psql, or delete and re-register the account.

### Events  `/events`  *(login required)*
| Method | Path | Description |
|--------|------|-------------|
| GET    | `/events`       | List my events |
| GET    | `/events/:id`   | Get event + RSVPs |
| POST   | `/events`       | `{title, location?, event_date?, config}` |
| PUT    | `/events/:id`   | Update any field |
| DELETE | `/events/:id`   | Delete (owner only) |
| POST   | `/events/:id/rsvp` | `{status}` — attending / maybe / declined |

### Share  `/share`  *(POST requires login; GET is public)*
| Method | Path | Description |
|--------|------|-------------|
| POST | `/share/:id/link`    | Generate public share token/URL |
| POST | `/share/:id/disable` | Revoke share link |
| GET  | `/share/view/:token` | Public: returns event JSON |

### Admin  `/admin`  *(admin role required)*
| Method | Path | Description |
|--------|------|-------------|
| GET    | `/admin/stats`           | Counts: users, events, RSVPs |
| GET    | `/admin/users`           | All users |
| PATCH  | `/admin/users/:id/role`  | `{role}` — promote / demote |
| DELETE | `/admin/users/:id`       | Delete user + their data |
| GET    | `/admin/events`          | All events |
| DELETE | `/admin/events/:id`      | Delete any event |

---

## Database Backups (Cron)

```bash
# crontab -e
# Daily 3 AM backup, keep 30 days
0 3 * * * pg_dump -U golf_user golf_scheduler > /var/backups/golf_$(date +\%Y\%m\%d).sql
0 4 * * * find /var/backups -name "golf_*.sql" -mtime +30 -delete
```

---

## Security Notes

- Passwords hashed with bcrypt (cost 12)
- Sessions: `HttpOnly`, `Secure` (prod), `SameSite: lax`, stored in PostgreSQL
- Helmet.js sets all recommended security headers incl. CSP
- Rate limiting: 10 auth requests / 15 min; 30 share requests / hour
- Input validated with `express-validator`, all DB queries parameterized
- Admin routes protected by role middleware
