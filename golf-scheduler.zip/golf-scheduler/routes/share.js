// routes/share.js
const express   = require('express');
const crypto    = require('crypto');
const rateLimit = require('express-rate-limit');
const { param, validationResult } = require('express-validator');
const { requireAuth } = require('../middleware/auth');
const pool = require('../db/db');

const router = express.Router();

// Rate limit share link generation
const shareLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 30,
  message: { error: 'Too many share requests. Try again later.' }
});

// ── POST /share/:id/link ──────────────────────────────────────────────────────
// Generate (or refresh) a public share link for an event
router.post('/:id/link', requireAuth, shareLimiter, [param('id').isInt()], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    // Must own the event
    const own = await pool.query(
      'SELECT id FROM events WHERE id=$1 AND creator_id=$2',
      [req.params.id, req.session.userId]
    );
    if (own.rows.length === 0) return res.status(403).json({ error: 'Forbidden.' });

    const token = crypto.randomBytes(32).toString('hex');
    const result = await pool.query(
      'UPDATE events SET share_token=$1, share_active=TRUE, updated_at=NOW() WHERE id=$2 RETURNING share_token',
      [token, req.params.id]
    );

    const shareUrl = `${process.env.APP_URL || 'http://localhost:3000'}/shared/${result.rows[0].share_token}`;
    res.json({ shareUrl, token: result.rows[0].share_token });
  } catch (err) {
    console.error('share/link:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /share/:id/disable ───────────────────────────────────────────────────
// Revoke a share link
router.post('/:id/disable', requireAuth, [param('id').isInt()], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const result = await pool.query(
      'UPDATE events SET share_active=FALSE, share_token=NULL, updated_at=NOW() WHERE id=$1 AND creator_id=$2 RETURNING id',
      [req.params.id, req.session.userId]
    );
    if (result.rows.length === 0) return res.status(403).json({ error: 'Forbidden.' });
    res.json({ message: 'Share link disabled.' });
  } catch (err) {
    console.error('share/disable:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /share/view/:token ────────────────────────────────────────────────────
// Public read-only view — no auth required
router.get('/view/:token', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT e.id, e.title, e.description, e.event_date, e.location,
              e.config, e.created_at, u.username AS creator
       FROM events e
       JOIN users u ON u.id = e.creator_id
       WHERE e.share_token = $1 AND e.share_active = TRUE`,
      [req.params.token]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Share link not found or has been disabled.' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error('share/view:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
