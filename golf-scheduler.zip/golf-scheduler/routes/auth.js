// routes/auth.js
const express  = require('express');
const bcrypt   = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');
const pool     = require('../db/db');

const router = express.Router();

// Rate limit auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  message: { error: 'Too many attempts, please try again later.' }
});

// ── POST /auth/register ────────────────────────────────────────────────────────
router.post('/register', authLimiter, [
  body('username').trim().isLength({ min: 3, max: 50 }).escape(),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { username, email, password } = req.body;
  try {
    const dup = await pool.query(
      'SELECT id FROM users WHERE username=$1 OR email=$2',
      [username, email]
    );
    if (dup.rows.length > 0) {
      return res.status(409).json({ error: 'Username or email already registered.' });
    }

    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      'INSERT INTO users (username, email, password) VALUES ($1, $2, $3) RETURNING id, username, role',
      [username, email, hash]
    );
    const user = result.rows[0];

    // Auto-login after registration
    req.session.userId   = user.id;
    req.session.username = user.username;
    req.session.role     = user.role;

    res.status(201).json({
      message: 'Registered successfully',
      user: { id: user.id, username: user.username, role: user.role }
    });
  } catch (err) {
    console.error('register:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /auth/login ───────────────────────────────────────────────────────────
router.post('/login', authLimiter, [
  body('login').trim().notEmpty(),   // accepts username OR email
  body('password').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { login, password } = req.body;
  try {
    const result = await pool.query(
      'SELECT * FROM users WHERE username=$1 OR email=$1',
      [login]
    );
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: 'Invalid credentials.' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Invalid credentials.' });

    req.session.userId   = user.id;
    req.session.username = user.username;
    req.session.role     = user.role;

    res.json({
      message: 'Logged in',
      user: { id: user.id, username: user.username, role: user.role }
    });
  } catch (err) {
    console.error('login:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /auth/logout ──────────────────────────────────────────────────────────
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.json({ message: 'Logged out' });
  });
});

// ── GET /auth/me ───────────────────────────────────────────────────────────────
router.get('/me', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Not authenticated' });
  res.json({
    id:       req.session.userId,
    username: req.session.username,
    role:     req.session.role
  });
});

// ── POST /auth/change-password ─────────────────────────────────────────────────
// Logged-in user changes their own password (no email required)
router.post('/change-password', [
  body('currentPassword').notEmpty(),
  body('newPassword').isLength({ min: 8 }),
], async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Not authenticated' });

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { currentPassword, newPassword } = req.body;
  try {
    const result = await pool.query('SELECT password FROM users WHERE id=$1', [req.session.userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found.' });

    const match = await bcrypt.compare(currentPassword, result.rows[0].password);
    if (!match) return res.status(401).json({ error: 'Current password is incorrect.' });

    const hash = await bcrypt.hash(newPassword, 12);
    await pool.query('UPDATE users SET password=$1, updated_at=NOW() WHERE id=$2', [hash, req.session.userId]);

    res.json({ message: 'Password changed successfully.' });
  } catch (err) {
    console.error('change-password:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
