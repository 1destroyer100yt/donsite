// routes/admin.js
const express = require('express');
const { param, body, validationResult } = require('express-validator');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const pool = require('../db/db');

const router = express.Router();
router.use(requireAuth, requireAdmin);

// ── GET /admin/users ─────────────────────────────────────────────────────────
router.get('/users', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, username, email, role, created_at,
              (SELECT COUNT(*) FROM events WHERE creator_id = u.id) AS event_count
       FROM users u
       ORDER BY created_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /admin/users/:id ─────────────────────────────────────────────────────
router.get('/users/:id', [param('id').isInt()], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try {
    const result = await pool.query('SELECT id, username, email, role, created_at FROM users WHERE id=$1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found.' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── PATCH /admin/users/:id/role ───────────────────────────────────────────────
router.patch('/users/:id/role', [
  param('id').isInt(),
  body('role').isIn(['admin', 'user']),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  // Prevent self-demotion
  if (parseInt(req.params.id) === req.session.userId && req.body.role !== 'admin') {
    return res.status(400).json({ error: 'Cannot demote yourself.' });
  }

  try {
    const result = await pool.query(
      'UPDATE users SET role=$1 WHERE id=$2 RETURNING id, username, role',
      [req.body.role, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found.' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── DELETE /admin/users/:id ───────────────────────────────────────────────────
router.delete('/users/:id', [param('id').isInt()], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  if (parseInt(req.params.id) === req.session.userId) {
    return res.status(400).json({ error: 'Cannot delete yourself.' });
  }

  try {
    const result = await pool.query('DELETE FROM users WHERE id=$1 RETURNING id', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found.' });
    res.json({ message: 'User deleted.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /admin/events ─────────────────────────────────────────────────────────
router.get('/events', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT e.id, e.title, e.event_date, e.location, e.share_active,
              e.created_at, u.username AS creator,
              (SELECT COUNT(*) FROM rsvps r WHERE r.event_id=e.id) AS rsvp_count
       FROM events e JOIN users u ON u.id = e.creator_id
       ORDER BY e.created_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── DELETE /admin/events/:id ──────────────────────────────────────────────────
router.delete('/events/:id', [param('id').isInt()], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try {
    const result = await pool.query('DELETE FROM events WHERE id=$1 RETURNING id', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Event not found.' });
    res.json({ message: 'Event deleted.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /admin/stats ──────────────────────────────────────────────────────────
router.get('/stats', async (req, res) => {
  try {
    const [users, events, rsvps] = await Promise.all([
      pool.query('SELECT COUNT(*) AS count FROM users'),
      pool.query('SELECT COUNT(*) AS count FROM events'),
      pool.query('SELECT COUNT(*) AS count FROM rsvps'),
    ]);
    res.json({
      total_users:  parseInt(users.rows[0].count),
      total_events: parseInt(events.rows[0].count),
      total_rsvps:  parseInt(rsvps.rows[0].count),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
